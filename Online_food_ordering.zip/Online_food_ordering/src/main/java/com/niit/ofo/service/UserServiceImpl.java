package com.niit.ofo.service;



import org.springframework.transaction.annotation.Transactional;

import com.niit.ofo.dao.*;
import com.niit.ofo.model.Customer;
import com.niit.ofo.model.User;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


//@Transactional annotations which is applied at service layer for transaction support.
//@Service annotation used to annotate service layer implementation classes as below.
@Service

public class UserServiceImpl implements UserService{
	@Autowired
	 private UserDAO userDAO;

	   public void setLoginDAO(UserDAO userDAO) {
             this.userDAO = userDAO;
      }
     
      public boolean checkLogin(String name, String password,String role){
             System.out.println("In Service class...Check Login");
             return userDAO.checkLogin(name, password,role);
      }

	
	
}