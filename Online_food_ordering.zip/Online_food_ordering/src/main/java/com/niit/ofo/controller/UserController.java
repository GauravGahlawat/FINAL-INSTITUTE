package com.niit.ofo.controller;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.ofo.model.Customer;
import com.niit.ofo.model.User;
import com.niit.ofo.service.CustomerService;
import com.niit.ofo.service.UserService;
import com.sun.javafx.collections.MappingChange.Map;

@Controller
@RequestMapping("/user")

	public class UserController {

	@Autowired
	public UserService userService;
	//@GetMapping("/getCustomer")
	@RequestMapping(method = RequestMethod.GET)
	public String showForm(Map model) {
		User user = new User();
		model.put("User", user);
		return "user-login";
	}

	@PostMapping("/checkUser")
	public String checkUser(@ModelAttribute("user") User theUser) {
		userService.saveCustomer(theCustomer);	
		return "redirect:/customer/list";
	}
	
	
	@RequestMapping(method = RequestMethod.POST)
	public String processForm(@Valid User User, BindingResult result,
			Map model) {

		
		if (result.hasErrors()) {
			return "user-login";
		}
		
		
		String name = "name";
		String password = "password";
		User = (User) model.get("User");
		if (!User.getName().equals(name)
				|| !User.getPassword().equals(password)) {
			return "user-login";
		}
		
		boolean userExists = UserService.checkLogin(User.getName(),
                User.getPassword(),User.getRole());
		if(userExists){
			model.put("User", User);
			return "loginsuccess";
		}else{
			result.rejectValue("userName","invaliduser");
			return "user-login";
		}

	}

}
