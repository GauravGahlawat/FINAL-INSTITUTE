package com.niit.ofo.dao;



import java.util.List;

import javax.annotation.Resource;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.ofo.model.Customer;
import com.niit.ofo.model.User;

// @Repository is an annotation that marks specific class as Data Access Object

@Repository
public class UserDAOImpl implements UserDAO{
	
	  @Resource(name="sessionFactory")
      protected SessionFactory sessionFactory;

      public void setSessionFactory(SessionFactory sessionFactory) {
             this.sessionFactory = sessionFactory;
      }
     
      protected Session getSession(){
             return sessionFactory.openSession();
      }

      public boolean checkLogin(String name, String password, String role){
    	  String c="c";
			System.out.println("In Check login");
			Session session = sessionFactory.openSession();
			boolean userFound = false;
			if(role==c) {
			//Query using Hibernate Query Language
			String SQL_QUERY =" from customer_details as o where o.name=? and o.password=? and o.role";
			Query query = session.createQuery(SQL_QUERY);
			query.setParameter(0,name);
			query.setParameter(1,password);
			List list = query.list();

			if ((list != null) && (list.size() > 0)) {
				userFound= true;
			}

			session.close();
			return userFound;              
      }
			else {
				String SQL_QUERY =" from restaurant_details as o where o.name=? and o.password=? and o.role";
				Query query = session.createQuery(SQL_QUERY);
				query.setParameter(0,name);
				query.setParameter(1,password);
				List list = query.list();

				if ((list != null) && (list.size() > 0)) {
					userFound= true;
				}

				session.close();
				return userFound;              
	      }
}
	}

