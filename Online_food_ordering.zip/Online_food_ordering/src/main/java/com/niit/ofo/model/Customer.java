package com.niit.ofo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customer_details")
public class Customer {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name="c_id")
private int id;
 @Column(name="c_name")
 private String Name;
 @Column(name="c_email")
 private String Email;
 @Column(name="c_phone")
 private String Phone;
 @Column(name="role")
 private String role;
 @Column(name="c_password")
 private String password;
 @Column(name="c_address")
 private String address;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public String getEmail() {
	return Email;
}
public void setEmail(String email) {
	Email = email;
}
public String getPhone() {
	return Phone;
}
public void setPhone(String phone) {
	Phone = phone;
}
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
@Override
public String toString() {
	return "Customer [id=" + id + ", Name=" + Name + ", Email=" + Email + ", Phone=" + Phone + ", role=" + role
			+ ", password=" + password + ", address=" + address + "]";
}

 
}
