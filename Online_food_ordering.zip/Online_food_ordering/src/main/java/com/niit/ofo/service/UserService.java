package com.niit.ofo.service;

import java.util.List;


import com.niit.ofo.model.User;



public interface UserService {
	public static boolean checkLogin(String name, String password , String role) {
		// TODO Auto-generated method stub
		return false;
	}

}
