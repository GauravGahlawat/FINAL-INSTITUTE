package com.niit.ofo.dao;
import java.util.List;

import com.niit.ofo.model.*;




public interface UserDAO {
	 public boolean checkLogin(String name, String password,String role);

}
