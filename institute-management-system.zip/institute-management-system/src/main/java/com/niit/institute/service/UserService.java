package com.niit.institute.service;

import com.niit.institute.model.User;

public interface UserService {
	

	public User checkUser(User theUser);

}
